import React, { useState, useEffect } from "react";
import Question from "./Question";
import "./QuizGame.css";

const API_URL = "https://opentdb.com/api.php?amount=5&category=30&difficulty=easy&type=boolean";

const QuizGame = ({ onGameOver }) => {
  const [questionData, setQuestionData] = useState(null);
  const [selectedAnswer, setSelectedAnswer] = useState(null);
  const [score, setScore] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchQuestion();
  }, []);

  const fetchQuestion = async () => {
    setLoading(true);
    try {
      const response = await fetch(API_URL);
      const data = await response.json();
      if (data.results && data.results.length > 0) {
        const question = data.results[0];
        const options = [...question.incorrect_answers, question.correct_answer].sort(() => Math.random() - 0.5);
        setQuestionData({ question: question.question, correct: question.correct_answer, options });
        setSelectedAnswer(null);
      } else {
        alert("Não foi possível carregar a pergunta. Tente novamente.");
      }
    } catch (error) {
      console.error("Erro ao buscar pergunta:", error);
      alert("Erro ao carregar a pergunta. Tente novamente.");
    }
    setLoading(false);
  };


  const handleAnswerClick = (answer) => {
    
    if (answer === questionData.correct) {
      setScore(score + 1);
      alert("Correto!");
    } else {
      alert("Errado! A resposta certa era: " + questionData.correct);
    }
    fetchQuestion();
  };

  return (
    <div className="quiz-container">
      <h1>Quiz Show do Milhão</h1>
      <h2>Pontuação: {score}</h2>
      {loading ? (
        <p>Carregando pergunta...</p>
      ) : (
        <Question 
          question={questionData.question} 
          options={questionData.options} 
          onAnswerClick={handleAnswerClick} 
        />
      )}
    </div>
  );
};

export default QuizGame;