import React from "react";
import "./Question.css"; // Arquivo CSS para estilização, se necessário

const Question = ({ question, options, onAnswerClick }) => {
  return (
    <div className="question-container">
      <p className="question-text" dangerouslySetInnerHTML={{ html: question }}></p>
      <div className="options">
        {options.map((option, index) => (
          <button
          key={index}
          onClick={() => onAnswerClick(option)}
          className="option-button"
          dangerouslySetInnerHTML={{ html: option }}
        />
        ))}
      </div>
    </div>
  );
};

export default Question;