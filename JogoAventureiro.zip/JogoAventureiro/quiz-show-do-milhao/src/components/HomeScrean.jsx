import React, {useState} from "react";

const HomeScreen = ({ onStartGame }) => {
  return (
    <div className="home-screen">
      <h1>Bem-vindo ao Quiz Show do Milhão!</h1>
      <button onClick={onStartGame}>Iniciar Jogo</button>
    </div>
  );
};

export default HomeScreen;