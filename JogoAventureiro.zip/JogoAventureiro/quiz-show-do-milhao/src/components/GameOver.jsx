import React, {useState} from "react";

const GameOver = ({ score, onRestart }) => {
  return (
    <div className="game-over">
      <h1>Fim de Jogo</h1>
      <p>Pontuação Final: {score}</p>
      <button onClick={onRestart}>Reiniciar Jogo</button>
    </div>
  );
};

export default GameOver; // Certifique-se de exportar o componente como default