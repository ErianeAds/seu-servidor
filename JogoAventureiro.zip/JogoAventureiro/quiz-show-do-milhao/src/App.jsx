
import React, { useState } from "react";
import QuizGame from "./components/QuizGame";
import HomeScreen from "./components/HomeScrean";
import GameOver from "./components/GameOver";
import './App.css';

function App() {
  const [gameState, setGameState] = useState('home'); // Tela atual do jogo
  const [score, setScore] = useState(0); // Pontuação do jogador

  const startGame = () => {
    setScore(0); // Reinicia a pontuação ao começar o jogo
    setGameState('quiz'); // Navega para a tela de quiz
  };

  const endGame = (finalScore) => {
    setScore(finalScore); // Atualiza a pontuação final
    setGameState('gameOver'); // Navega para a tela de fim de jogo
  };

  const restartGame = () => {
    setScore(0); // Reinicia a pontuação
    setGameState('home'); // Volta para a tela inicial
  };

  return (
    <div className="app">
      {gameState === 'home' && <HomeScreen onStartGame={startGame} />}
      {gameState === 'quiz' && <QuizGame onGameOver={endGame} />}
      {gameState === 'gameOver' && <GameOver score={score} onRestart={restartGame} />}
    </div>
  );
}

export default App;